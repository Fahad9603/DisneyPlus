import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { signInUser, signOut } from '../features/auth/authSliec';
import { selectUserName, setUserLogin } from '../features/user/UserSliec';
import styled from 'styled-components';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase'; // Make sure this import is correct
import { useNavigate, Link } from 'react-router-dom';
import { getAuth } from "firebase/auth";

const SignIn = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();  // Corrected to useNavigate
  const auth = getAuth();
  const { loading, error, step, userPhoto } = useSelector((state) => state.auth);
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (userAuth) => {
      if (userAuth) {
        const userRef = doc(db, 'users', userAuth.uid);  // Get the reference first
        const userDoc = await getDoc(userRef);  // Fetch the document using the reference
  
        if (userDoc.exists()) {
          const userData = userDoc.data();
  
          dispatch(setUserLogin({
            uid: userAuth.uid,
            displayName: userAuth.displayName || userData?.displayName,
            email: userAuth.email,
            img: userData?.img || '',
          }));
      
  console.log(userData.displayName)
          if (userData.displayName) {
            navigate("/home");
          } else {
            navigate("/SignIn");
          }
        } else {
          navigate("/login");
        }
      }
    });
  
    return () => unsubscribe();
  }, [dispatch, auth, navigate]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await dispatch(signInUser({ email, password }));
      // Check if the user is valid here, and navigate accordingly
      if (email) {
        navigate("/home");
      } else {
        navigate("/SignIn");
      }
    } catch (err) {
      console.error("Error during sign-in:", err);
      // Optionally show an error message to the user
    }
  };
  

  const handleSignOut = async () => {
    try {
      await auth.signOut();
      dispatch(signOut());
      navigate("/login");
    } catch (err) {
      console.error("Error signing out:", err);
    }
  };
  

  return (
    <Container>
      {!email ? (
        <Main>
          <StepIndicator>STEP {step} OF 3</StepIndicator>
          <Title>Welcome back!</Title>
          <Subtitle>Joining Disney+ is easy.</Subtitle>
          <Description>Enter your email and password to sign in.</Description>

          <Form onSubmit={handleSubmit}>
            <FormGroup>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                required
              />
            </FormGroup>

            <FormGroup>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
              />
            </FormGroup>

            {error && <ErrorMessage>{error}</ErrorMessage>}

            <ForgotPasswordLink to="/forgot-password">
              Forgot your password?
            </ForgotPasswordLink>

            <SubmitButton type="submit" disabled={loading}>
              {loading ? 'Loading...' : 'Next'}
            </SubmitButton>
          </Form>
        </Main>
      ) : (
        <Nav>
          <Logo to="/">
            <img src="/images/logo.svg" alt="Disney+" />
          </Logo>
          <NavMenu />
          <SignOut onClick={handleSignOut}>
            <UserImg src={userPhoto} alt={'User1'} />
            <DropDown>
              <span>Sign out</span>
            </DropDown>
          </SignOut>
        </Nav>
      )}
    </Container>
  );
};

const Container = styled.div`
  position: relative;
  min-height: calc(100vh - 72px);
  overflow-x: hidden;
  display: block;
  top: 60px;
  margin-bottom: auto;
  padding: 0 calc(3.5vw + 5px);

  &:after {
    background: url("/images/home-background.png") center center / cover no-repeat fixed;
    content: "";
    position: absolute;
    inset: 0px;
    opacity: 1;
    z-index: -1;
  }
`;

const Main = styled.main`
  max-width: 28rem;
  margin: 0 auto;
  padding: 0 1rem;
  padding-top: 3rem;
`;

const StepIndicator = styled.div`
  font-size: 0.75rem;
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 500;
  margin-top: 1rem;
`;

const Subtitle = styled.h2`
  font-size: 2rem;
  font-weight: 500;
`;

const Description = styled.p`
  font-size: 1.125rem;
  margin-top: 1rem;
`;

const Form = styled.form`
  margin-top: 1.5rem;
`;

const FormGroup = styled.div`
  margin-bottom: 1rem;
`;

const Label = styled.label`
  display: block;
  font-size: 0.875rem;
  margin-bottom: 0.25rem;
`;

const Input = styled.input`
  width: 100%;
  padding: 1rem;
  border: 1px solid #333;
  border-radius: 0.25rem;
  font-size: 1rem;
`;

const ErrorMessage = styled.div`
  color: #e50914;
  font-size: 0.875rem;
  margin-top: 0.5rem;
`;

const ForgotPasswordLink = styled(Link)`
  display: block;
  font-size: 0.875rem;
  color: #0071eb;
  text-decoration: none;
  margin-top: 1rem;
  &:hover {
    text-decoration: underline;
  }
`;

const SubmitButton = styled.button`
  width: 100%;
  background-color: #0063e5;
  color: white;
  padding: 1rem 2rem;
  border: none;
  border-radius: 0.25rem;
  font-size: 1.125rem;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 0.2s;
  margin-top: 1.5rem;

  &:hover {
    background-color: #0483ee;
  }

  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
`;

const Nav = styled.nav`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 72px;
  background-color: #090b13;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 36px;
  letter-spacing: 16px;
  z-index: 3;
`;

const Logo = styled(Link)`
  padding: 0;
  width: 80px;
  margin-top: 4px;
  max-height: 70px;
  font-size: 0;
  display: inline-block;

  img {
    display: block;
    width: 100%;
  }
`;

const NavMenu = styled.div`
  align-items: center;
  display: flex;
  flex-flow: row nowrap;
  height: 100%;
  justify-content: flex-end;
  margin: 0px;
  padding: 0px;
  position: relative;
  margin-right: auto;
  margin-left: 25px;
`;

const UserImg = styled.img`
  height: 100%;
  width: 100%;
  border-radius: 50%;
`;

const DropDown = styled.div`
  position: absolute;
  top: 48px;
  right: 0px;
  background: rgb(19, 19, 19);
  border: 1px solid rgba(151, 151, 151, 0.34);
  border-radius: 4px;
  box-shadow: rgb(0 0 0 / 50%) 0px 0px 18px 0px;
  padding: 10px;
  font-size: 14px;
  letter-spacing: 3px;
  width: 100px;
  opacity: 0;
`;

const SignOut = styled.div`
  position: relative;
  height: 48px;
  width: 48px;
  display: flex;
  cursor: pointer;
  align-items: center;
  justify-content: center;

  ${UserImg} {
    border-radius: 50%;
    width: 100%;
    height: 100%;
  }

  &:hover {
    ${DropDown} {
      opacity: 1;
      transition-duration: 1s;
    }
  }
`;

export default SignIn;
