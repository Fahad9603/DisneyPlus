import React, { useRef, useState } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import { auth,createUserWithEmailAndPassword } from '../firebase'; // Import necessary functions from firebase

function Login() {
  const history = useNavigate();
  const emailref = useRef(null);
  const Passwordlref = useRef(null);

  const register = (e) => {
    e.preventDefault(); // Correct the function name

    createUserWithEmailAndPassword(auth, emailref.current.value, Passwordlref.current.value)
      .then((authUser) => {
        console.log(authUser);
        history('/Plan-Selection');
      })
      .catch((error) => {
        alert(error.message);
      });
  };


  return (
    <Container>
      <CTA>
        <CTALogoOne src="/images/cta-logo-one.svg" />
        <input ref={emailref} type='email' name='email'></input>
        <input ref={Passwordlref} type='Password' name='password'></input>
          <SignUp onClick={register}>GET ALL THERE</SignUp>
        <Description>
          Stream brand new Originals, blockbusters, binge-worthy series, and more.
          All at no extra cost. Cancel at any time.*
          Enter your email to create or restart your subscription.
        </Description>
        <CTALogoTwo src="/images/cta-logo-two.png" />
      </CTA>
    </Container>
  );
}

export default Login;

const Container = styled.div`
  position: inherit;
  height: calc(100vh - 70px);
  display: flex;
  align-items: top;
  justify-content: center;

  &:before {
    background-position: top;
    background-size: cover;
    background-repeat: no-repeat;
    background-image: url("/images/login-background.jpg");
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    opacity: 0.7;
    z-index: -1;
  }
`;

const CTA = styled.div`
  max-width: 650px;
  padding: 80px 40px;
  width: 90%;
  display: flex;
  flex-direction: column;
  margin-top: 70px;
  align-items: center;
`;

const FormContainer = styled.div`
  display: flex;
  width: 100%;
  background: #1c1c1c;
  border-radius: 5px;
  overflow: hidden;
`;

const CTALogoOne = styled.img`
  max-width: 100%;
  margin-bottom: 20px;
`;

const SignUp = styled.button`
   width: 100%;
    background-color: #0063e5;
    font-weight: bold;
    padding: 17px 0;
    color: #f9f9f9;
    border-radius: 4px;
    text-align: center;
    font-size: 18px;
    cursor: pointer;
    transition: all 250ms;
    letter-spacing: 1.5px;
    margin-top: 8px;
    margin-bottom: 12px;

    &:hover {
        background: #0483ee;
    }`;

const Description = styled.p`
  font-size: 12px;
  letter-spacing: 1.5px;
  text-align: center;
  line-height: 1.5;
`;

const CTALogoTwo = styled.img`
  width: 100%;
`;

const EmailInput = styled.input`
  flex: 1;
  padding: 15px;
  background: #31343e;
  color: #f9f9f9;
  border: none;
  width: 100%;
  font-size: 16px;
  outline: none;

  &::placeholder {
    color: #bbb;
  }
`;

const Error = styled.p`
  color: red;
  font-size: 14px;
  text-align: center;
`;

