import React, { useRef, useEffect,useState } from 'react';
import styled from "styled-components";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { selectMovies } from "../features/movie/movieSliec";

const Movies = (props) => {
  const movies = useSelector(selectMovies) || []; 
  const containerRef = useRef(null);
  const [isScrolledLeft, setIsScrolledLeft] = useState(true);
  const [isScrolledRight, setIsScrolledRight] = useState(false);

  useEffect(() => {
    const container = containerRef.current;

    const handleScroll = () => {
      setIsScrolledLeft(container.scrollLeft === 0);
      setIsScrolledRight(container.scrollWidth - container.clientWidth === container.scrollLeft);
    };

    const handleWheel = (event) => {
      event.preventDefault();
      container.scrollLeft += event.deltaY;
      handleScroll();
    };

    container.addEventListener('wheel', handleWheel);
    container.addEventListener('scroll', handleScroll);

    return () => {
      container.removeEventListener('wheel', handleWheel);
      container.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Function to handle right scroll
  const scrollRight = () => {
    containerRef.current.scrollLeft += 300;
  };

  // Function to handle left scroll
  const scrollLeft = () => {
    containerRef.current.scrollLeft -= 300;
  };

  return (
    <Container>
      <h4>New to Disney+</h4>
      {movies.length > 4 && <LeftArrow onClick={scrollLeft}><span>{"<"}</span></LeftArrow>}
      <Content ref={containerRef}>
        {movies &&
          movies.map((movie, key) => (
            <Wrap key={key}>
              {movie.id}
              <Link to={`/detail/` + movie.id}>
                <img src={movie.cardImg} alt={movie.title} />
              </Link>
            </Wrap>
          ))}
      </Content>
      {movies.length > 4 && <RightArrow onClick={scrollRight}><span>{">"}</span></RightArrow>}
    </Container>
  );
};


const Container = styled.div`
  padding: 0 0 26px;
  position: relative;
`;

const Content = styled.div`
  display: grid;
  grid-gap: 25px;
  gap: 25px;
  grid-auto-flow: column;
  grid-auto-columns: minmax(25%, 1fr); 
  @media (max-width: 768px) {
    grid-auto-columns: minmax(50%, 1fr); 
  }
  overflow-x: auto;
  overflow-y: hidden;
  scroll-behavior: smooth; /* Smooth scroll */
  &::-webkit-scrollbar {
    display: none;
  }
`;

const Wrap = styled.div`
  padding-top: 56.25%;
  border-radius: 10px;
  box-shadow: rgb(0 0 0 / 69%) 0px 26px 30px -10px,
    rgb(0 0 0 / 73%) 0px 16px 10px -10px;
  cursor: pointer;
  position: relative;
  transition: all 250ms cubic-bezier(0.25, 0.46, 0.45, 0.94) 0s;
  border: 3px solid rgba(249, 249, 249, 0.1);

  img {
    inset: 0px;
    display: block;
    height: 100%;
    object-fit: cover;
    opacity: 1;
    position: absolute;
    transition: opacity 500ms ease-in-out 0s;
    width: 100%;
    z-index: 1;
    top: 0;
  }

  &:hover {
    box-shadow: rgb(0 0 0 / 80%) 0px 40px 58px -16px,
      rgb(0 0 0 / 72%) 0px 30px 22px -10px;
    transform: scale(1.05);
    border-color: rgba(249, 249, 249, 0.8);
  }
`;

const Arrow = styled.div`
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  z-index: 2;
  cursor: pointer;
  font-size: 3rem;
  color: white;
  background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  user-select: none;
  transition: opacity 0.3s ease;

  &:hover {
    opacity: 0.8;
  }

  span {
    font-size: 2rem; /* Adjust the font size to match the icon */
  }
`;

const LeftArrow = styled(Arrow)`
    opacity: 0;
    left: -45px;
      color: white;
    &:hover {
      opacity: 1;
      transition: opacity 0.2s ease 0s;
    }
`;

const RightArrow = styled(Arrow)`
  right: 10px;
`;

export default Movies;
