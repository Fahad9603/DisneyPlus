import React, { useState, useEffect } from "react";
import { db } from "../firebase";  
import styled from 'styled-components';
import {selectUserEmail} from "../features/user/UserSliec";
import { collection, query, where, getDocs ,doc,addDoc, snapshotEqual} from "firebase/firestore"; 
import { loadStripe } from '@stripe/stripe-js';
import { useSelector } from "react-redux";
import { color } from "@mui/system";


function PlanScreen() {
  const [products, setProduct] = useState({});
  const [selectedProductId, setSelectedProductId] = useState(null);
  const user =useSelector(selectUserEmail);
  useEffect(() => {
    if (selectedProductId && products[selectedProductId]) {
      console.log("Product" + products[selectedProductId].priceId);
    }
  }, [selectedProductId, products]);

  useEffect(() => {
    const fetchProducts = async () => {
      const q = query(collection(db, "products"), where("active", "==", true));
      const querySnapshot = await getDocs(q);
      const products = {};

      querySnapshot.forEach((productsDoc) => {
        products[productsDoc.id] = productsDoc.data();
      });

      setProduct(products);
    };

    fetchProducts();
  }, []);

const loadCheckout = async (priceId) =>{
  const docRef = await db
  .collection("customers")
  .doc(user.userid)
  .collection("checkout-sessions")
  .add({
    price: priceId,
    success_url: window.location.origin,
    cancel_url: window.location.origin,
  });
  docRef.onSnapshot(async (snap) => {
    const {error, sessionId} =snap.data();
    if (error)
    {
      alert(`An error occured : ${error.message}`);

    }
    if(sessionId){
      const stripe = await loadStripe('pk_test_51QWBK7BLG9FMSoXa4lrQSG8BvSlLJ9J1hYpGSj3ctIPFc7RaTDFrFL0oH0RgX3kN1jc0rGSUEcRqmbDrpETT8pAg00ROBOZh0x');
      stripe.redirectToCheckout({sessionId})
    }
  })
}

  return (
    <Container>
      <Card>
        <Title>Disney+ Subscription</Title>
        <Form action="submit">
          <EmailHeading>{user}</EmailHeading>  

          {/* Displaying Products */}
          <ProductsContainer>
            {Object.keys(products).length > 0 ? (
              Object.keys(products).map((productId) => {
                const product = products[productId];
                const isSelected = selectedProductId === productId;

                return (
                  <ProductCard
                    key={productId}
                    onClick={() => setSelectedProductId(productId)}
                    isSelected={isSelected}
                    disabled={isSelected}
                  >
                    <h3>{product.name}</h3>
                    <p>{product.description}</p>
                    <p>Price: ${product.price}</p>
                  </ProductCard>
                );
              })
            ) : (
              <p>Loading products...</p>
            )}
          </ProductsContainer>

          {selectedProductId && products[selectedProductId] && (
            <Button onClick={() => loadCheckout(products[selectedProductId].priceId)}>
              Subscribe Now
            </Button>
          )}  
        </Form>
      </Card>
    </Container>
  );
}

export const Container = styled.div`
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
`;

export const Card = styled.div`
  background-color: white;
  border-radius: 10px;
  padding: 30px;
  width: 100%;
  max-width: 400px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`;

export const Title = styled.h1`
  color: #0b2b5e;
  font-size: 24px;
  text-align: center;
  margin-bottom: 20px;
`;
export const EmailHeading = styled.h2`
  color: black;`
export const Form = styled.form`
  display: flex;
  flex-direction: column;
`;

export const Input = styled.input`
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
`;

export const RadioGroup = styled.div`
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
`;

export const RadioLabel = styled.label`
  display: flex;
  align-items: center;
  margin-bottom: 10px;
  cursor: pointer;
`;

export const RadioInput = styled.input`
  margin-right: 10px;
`;

export const Button = styled.button`
  background-color: #0063e5;
  color: white;
  padding: 12px;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #0056b3;
  }
`;

export const ErrorMessage = styled.p`
  color: red;
  font-size: 14px;
  margin-top: 10px;
`;

// New styled component to display products
export const ProductsContainer = styled.div`
  margin-top: 20px;
`;

export const ProductCard = styled.div`
  background-color: rgb(116, 113, 113);
  padding: 15px;
  border-radius: 8px;
  margin-bottom: 15px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: pointer;

  h3 {
    color: #0b2b5e;
  }

  p {
    color: #555;
  }

  /* Styles for selected product */
  background-color: ${({ isSelected }) => (isSelected ? '#d1e0ff' : 'rgb(255, 255, 255)')};
  opacity: ${({ disabled }) => (disabled ? 0.5 : 1)};  // Disable opacity for unselected products

  &:hover {
    background-color: ${({ disabled }) => (disabled ? 'rgb(255, 255, 255)' : '#f1f1f1')};  // Hover effect for enabled products only
  }
`;

export default PlanScreen;
