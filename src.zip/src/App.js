import React from 'react';
import { Counter } from './features/counter/Counter';
import './App.css';
import { AuthProvider } from './features/auth/AuthContext';
import Header from './components/Header';
import Home from './components/Home';
import Search from './components/Search';
import Wishlist from './components/WishList';
import Series from './components/Series';
import SeriesEpisode from './components/SeriesEpisode';
import Movies from './components/Movies';
import Originals from './components/Originals';
import Detail from './components/Detail';
import Login from './components/Login';
import SubscribePage from './components/Plan-Selection';
import Footer from './components/Footer';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate
} from "react-router-dom";
import SignIn from './components/SignIn';

function App() {
  return (
    <div className="App">
      <Router>
        <Header />
        <Routes>
          <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/login" element={<Login />} />
          <Route path='/plan-selection' element={<SubscribePage/>}/>
          <Route path="/SignIn" element={<AuthProvider><SignIn /></AuthProvider>} />
          <Route path="/detail/:id" element={<Detail />} />
          <Route path="/home" element={<Home />} />
          <Route path="/originals" element={<Originals />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/series" element={<Series />} />
          <Route path="/seriesepisode/:id" element={<SeriesEpisode />} />
          <Route path="/movies" element={<Movies />} />
          <Route path="/search" element={<Search />} />
        </Routes>
        {/* <Footer /> */}
      </Router>
    </div>
  );
}

export default App;
