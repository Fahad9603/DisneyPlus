import { configureStore } from '@reduxjs/toolkit';
import UserSlice from '../features/user/UserSliec';
import movieReducer from '../features/movie/movieSliec';
import authReducer from '../features/auth/authSliec';

export const store = configureStore({
  reducer: {
    movie: movieReducer,
    user: UserSlice,
    auth: authReducer
  },
});

// export type RootState = ReturnType<typeof store.getState>;
// export type AppDispatch = typeof store.dispatch;

export default store;

